# Blood-donation-website
This is  a blood donation website made in HTML, CSS and JavaScript. I made this for my Web Development project. It is not a fully functioning website. It is just to show the frontend part of my website.

You can view the website by clicking on the following link: https://andyyad.github.io/Blood-donation-website/

Quick peek: 

![image](https://user-images.githubusercontent.com/80671044/202892694-16bdda3d-479a-44ee-8cf1-4700c2cf33a6.png)

![image](https://user-images.githubusercontent.com/80671044/202892719-4857fbb8-ea41-48c2-b937-bceafd1b8752.png)

![image](https://user-images.githubusercontent.com/80671044/202892755-2216b121-1374-4766-a8d4-5954070f6227.png)
